// src/firebase.js
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, get } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyDZtGPs_0dIaBz2pOM5E_SnizPKcHSqH2E",
  authDomain: "basiclogintoapp.firebaseapp.com",
  databaseURL: "https://basiclogintoapp-default-rtdb.firebaseio.com",
  projectId: "basiclogintoapp",
  storageBucket: "basiclogintoapp.appspot.com",
  messagingSenderId: "588108613584",
  appId: "1:588108613584:android:abf8d0dc6bfcf06f5e9bd5",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Get a reference to the database
const database = getDatabase(app);

export { database, ref, get };  // Export the necessary methods for use in other parts of the app
