import React, { useState, useEffect } from "react";
import { database, ref, get } from "./firebase";
import { GoogleGenerativeAI } from "@google/generative-ai";

const MISTRAL_API_KEY = "AIzaSyCgdOJIL4z6CrBnP2YKFLh1nVRV0-ssQYI";
const MISTRAL = "gemini-pro";

const HeartRate = () => {
  const [heartRates, setHeartRates] = useState([]);
  const [vitalsData, setVitalsData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [healthAnalysis, setHealthAnalysis] = useState("");
  const [lastAnalyzedData, setLastAnalyzedData] = useState(null);

  useEffect(() => {
    const vitalsRef = ref(database, "vitals");

    const fetchData = async () => {
      try {
        const vitalsSnapshot = await get(vitalsRef);
        if (vitalsSnapshot.exists()) {
          const vitalsArray = [];
          vitalsSnapshot.forEach((child) => {
            vitalsArray.push(child.val());
          });
          
          // Extract heart rates from vitals data
          const heartRateValues = vitalsArray.map(vital => vital.heartRate);
          
          setHeartRates(heartRateValues);
          setVitalsData(vitalsArray);
          setIsLoading(false);

          // Check if we have new data to analyze
          const currentData = {
            heartRates: heartRateValues,
            vitals: vitalsArray
          };

          // Only trigger new analysis if data has changed
          if (!lastAnalyzedData || 
              JSON.stringify(currentData) !== JSON.stringify(lastAnalyzedData)) {
            await analyzeVitals(heartRateValues, vitalsArray);
            setLastAnalyzedData(currentData);
          }
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setIsLoading(false);
      }
    };

    fetchData();
    const intervalId = setInterval(fetchData, 5000);

    return () => clearInterval(intervalId);
  }, [lastAnalyzedData]);

  const analyzeVitals = async (heartRates, vitals) => {
    if (heartRates.length === 0 || vitals.length === 0) {
      return; // Don't analyze if there's no data
    }

    const genAI = new GoogleGenerativeAI(MISTRAL_API_KEY);
    const model = genAI.getGenerativeModel({ model: MISTRAL });

    const avgHeartRate = heartRates.reduce((sum, rate) => sum + rate, 0) / heartRates.length;
    const bpReadings = vitals.map(v => `${v.systolic}/${v.diastolic}`).join(", ");
    const oxygenLevels = vitals.map(v => v.oxygenLevel).join(", ");

    const prompt = `Based on the following vital signs:
    - Heart Rate Dataset: ${heartRates.join(", ")} (Average: ${avgHeartRate} bpm)
    - Blood Pressure Readings: ${bpReadings} mmHg
    - Oxygen Levels: ${oxygenLevels}%
    
    Analyze these vitals together and tell me what this person's condition might be. Give me one single response considering all vitals together. Start with "You likely have"`;

    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      setHealthAnalysis(text);
    } catch (error) {
      console.error("Error with Gemini API:", error);
    }
  };

  return (
    <div>
      {/* Vitals Display Grid */}
      <div className="grid grid-cols-3 gap-4 mb-4">
        {/* Heart Rate Display Section */}
        <div className="h-[400px] overflow-y-auto p-4 border border-gray-300 rounded-lg">
          <h1 className="text-xl font-semibold mb-4">Heart Rate Monitor</h1>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            <div>
              {heartRates.length > 0 ? (
                heartRates.map((rate, index) => {
                  const isAnomaly = rate > 110;
                  return (
                    <div
                      key={index}
                      className={`mb-2 p-2 rounded ${isAnomaly ? "bg-red-500 text-white" : "bg-green-500 text-white"}`}
                    >
                      <p>Heart Rate: {rate} bpm</p>
                      {isAnomaly && <p>Anomaly Detected: Heart rate above 110!</p>}
                    </div>
                  );
                })
              ) : (
                <p>No heart rate data available</p>
              )}
            </div>
          )}
        </div>

        {/* Blood Pressure Display Section */}
        <div className="h-[400px] overflow-y-auto p-4 border border-gray-300 rounded-lg">
          <h1 className="text-xl font-semibold mb-4">Blood Pressure Monitor</h1>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            <div>
              {vitalsData.length > 0 ? (
                vitalsData.map((vital, index) => {
                  const isHighBP = vital.systolic > 140 || vital.diastolic > 90;
                  return (
                    <div
                      key={index}
                      className={`mb-2 p-2 rounded ${isHighBP ? "bg-red-500 text-white" : "bg-green-500 text-white"}`}
                    >
                      <p>BP: {vital.systolic}/{vital.diastolic} mmHg</p>
                      {isHighBP && <p>Anomaly Detected: High blood pressure!</p>}
                    </div>
                  );
                })
              ) : (
                <p>No blood pressure data available</p>
              )}
            </div>
          )}
        </div>

        {/* Oxygen Level Display Section */}
        <div className="h-[400px] overflow-y-auto p-4 border border-gray-300 rounded-lg">
          <h1 className="text-xl font-semibold mb-4">Oxygen Level Monitor</h1>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            <div>
              {vitalsData.length > 0 ? (
                vitalsData.map((vital, index) => {
                  const isLowOxygen = vital.oxygenLevel < 95;
                  return (
                    <div
                      key={index}
                      className={`mb-2 p-2 rounded ${isLowOxygen ? "bg-red-500 text-white" : "bg-green-500 text-white"}`}
                    >
                      <p>O2 Level: {vital.oxygenLevel}%</p>
                      {isLowOxygen && <p>Anomaly Detected: Low oxygen level!</p>}
                    </div>
                  );
                })
              ) : (
                <p>No oxygen level data available</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* AI Analysis Section */}
      <div className="w-full p-4 border border-gray-300 rounded-lg">
        <h1 className="text-xl font-semibold mb-4">Health Analysis</h1>
        {healthAnalysis ? (
          <p>{healthAnalysis}</p>
        ) : (
          <p>Waiting for initial vital signs data...</p>
        )}
      </div>
    </div>
  );
};

export default HeartRate;