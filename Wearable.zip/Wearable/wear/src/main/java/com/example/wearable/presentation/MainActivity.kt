

package com.example.wearable.presentation

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.wear.compose.material.*
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private lateinit var database: DatabaseReference
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    // Predefined vital sign readings
    private val systolicReadings = listOf(110, 112, 114, 116, 118, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 109, 110)
    private val diastolicReadings = listOf(75, 77, 79, 80, 82, 83, 84, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76, 75, 76, 77)
    private val oxygenLevels = listOf(85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 99, 98, 97, 96)
    private val heartRateReadings = listOf(60, 62, 64, 66, 69, 72, 75, 79, 83, 87, 91, 95, 99, 103, 107, 111, 115, 119, 118, 116)

    data class VitalSigns(
        val systolic: Int,
        val diastolic: Int,
        val oxygenLevel: Int,
        val heartRate: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference

        setTheme(android.R.style.Theme_DeviceDefault)
        setContent {
            var currentVitals by remember { mutableStateOf(VitalSigns(0, 0, 0, 0)) }
            var showAlert by remember { mutableStateOf(false) }
            var isMonitoring by remember { mutableStateOf(false) }
            var job by remember { mutableStateOf<Job?>(null) }

            WearApp(
                vitals = currentVitals,
                showAlert = showAlert,
                isMonitoring = isMonitoring,
                onStartClick = {
                    if (!isMonitoring) {
                        isMonitoring = true
                        job = coroutineScope.launch {
                            pushVitalsToFirebase { vitals ->
                                currentVitals = vitals
                                // Alert if systolic > 140 or diastolic > 90 or oxygen < 90 or heart rate > 100
                                showAlert = vitals.systolic > 140 ||
                                        vitals.diastolic > 90 ||
                                        vitals.oxygenLevel < 90 ||
                                        vitals.heartRate > 100
                            }
                            // Reset when finished
                            withContext(Dispatchers.Main) {
                                isMonitoring = false
                                currentVitals = VitalSigns(0, 0, 0, 0)
                                showAlert = false
                            }
                        }
                    }
                }
            )
        }
    }

    private suspend fun pushVitalsToFirebase(updateUI: (VitalSigns) -> Unit) {
        repeat(20) { index ->
            val vitalsRef = database.child("vitals")
            val timestamp = System.currentTimeMillis()

            val vitals = VitalSigns(
                systolic = systolicReadings[index],
                diastolic = diastolicReadings[index],
                oxygenLevel = oxygenLevels[index],
                heartRate = heartRateReadings[index]
            )

            val uniqueKey = vitalsRef.push().key

            uniqueKey?.let {
                vitalsRef.child(it).apply {
                    child("timestamp").setValue(timestamp)
                    child("systolic").setValue(vitals.systolic)
                    child("diastolic").setValue(vitals.diastolic)
                    child("oxygenLevel").setValue(vitals.oxygenLevel)
                    child("heartRate").setValue(vitals.heartRate)
                }
            }

            // Update UI on the main thread
            withContext(Dispatchers.Main) {
                updateUI(vitals)
            }

            delay(1000L) // 1-second buffer
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        coroutineScope.cancel()
    }
}

@Composable
fun WearApp(
    vitals: MainActivity.VitalSigns,
    showAlert: Boolean,
    isMonitoring: Boolean,
    onStartClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!isMonitoring) {
                Button(
                    onClick = onStartClick,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text(" ")
                }
            }

            VitalsDisplay(vitals)

            if (showAlert) {
                AlertMessage()
            }
        }
    }
}

@Composable
fun VitalsDisplay(vitals: MainActivity.VitalSigns) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "BP: ${vitals.systolic}/${vitals.diastolic}",
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Text(
            text = "O₂: ${vitals.oxygenLevel}%",
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Text(
            text = "❤️ ${vitals.heartRate} BPM",
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AlertMessage() {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Text(
        text = "⚠ Abnormal Vitals! ⚠",
        color = Color.Red.copy(alpha = alpha),
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 16.dp)
    )
}