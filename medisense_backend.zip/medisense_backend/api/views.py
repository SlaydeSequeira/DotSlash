from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from firebase_admin import db
import uuid
from datetime import datetime
from django.http import JsonResponse
import re
import google.generativeai as genai
import PyPDF2
import docx
import random
import string
import hashlib


# Declare patient_report as a global variable
patient_report = ""



# API to Register a New User
@api_view(['POST'])
def register_user(request):
    username = request.data.get('username')
    password = request.data.get('password')
    email = request.data.get('email', '')  # Optional email field

    if User.objects.filter(username=username).exists():
        return Response({'error': 'User already exists'}, status=status.HTTP_400_BAD_REQUEST)

    user = User.objects.create_user(username=username, password=password, email=email)

    # Register the user in Firebase Realtime Database
    users_ref = db.reference("Users/patients")
    user_ref = users_ref.child(str(user.id))  # Store under user ID

    user_data = {
        "username": user.username,
        "email": user.email,
        "joined_at": str(user.date_joined),
    }
    user_ref.set(user_data)

    return Response({'message': 'User registered successfully'}, status=status.HTTP_201_CREATED)


# API to Login a User (without JWT token)
@api_view(['POST'])
def login_user(request):
    username = request.data.get('username')
    password = request.data.get('password')

    user = authenticate(username=username, password=password)
    if user:
        # Reference to the "Users" node in Firebase Realtime Database
        users_ref = db.reference("Users/patients")
        user_ref = users_ref.child(str(user.id))  # Using user.id as a unique identifier

        # Check if user already exists in Firebase
        if not user_ref.get():
            # Register the user in Firebase
            user_data = {
                "username": user.username,
                "email": user.email,
                "joined_at": str(user.date_joined),
            }
            user_ref.set(user_data)

        return Response({'message': 'Login successful', 'user': {'id': user.id, 'username': user.username, 'email': user.email}})

    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)


# API to Get All Doctors
@api_view(['GET'])
def get_all_doctors(request):
    doctors_ref = db.reference("Users/doctors")
    doctors = doctors_ref.get()
    
    if not doctors:
        return Response({'message': 'No doctors found'}, status=status.HTTP_404_NOT_FOUND)
    
    return Response({'doctors': doctors}, status=status.HTTP_200_OK)

# Load API key from environment variable (or hardcode for testing)
API_KEY = "AIzaSyDjqhsufORRiqwiKnZPQjZozxG4T2r3Yo8"

# Configure Gemini
genai.configure(api_key=API_KEY)

@api_view(['POST'])
def generate_diagnosis(request):
    """Sends a prompt to Google Gemini and returns the response."""
    try:
        # Get the prompt from request data
        prompt = "For this following patient report, report: "+patient_report+ ". Generate a diagnosis of minimum 30 words, in which you explain how you came to this diagnosis for this patient. do not include special symbols like * or nextline characters in the generated text, return a clean text. Generate a diagnosis regardless of any amount of data i provide"

        if not prompt:
            return JsonResponse({"error": "Prompt is required"}, status=400)

        # Initialize the Gemini model
        model = genai.GenerativeModel("gemini-pro")

        print(prompt)
        # Send the prompt
        response = model.generate_content(prompt)

        # Extract response text
        generated_text = response.text if response.text else "No response from Gemini."

        return JsonResponse({"response": generated_text}, json_dumps_params={'indent': 4})

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
@api_view(['POST'])
def generate_prescription(request):
    """Generate a prescription from a document using Gemini."""
    
    # Check if the request contains a file
    if 'file' not in request.FILES:
        return JsonResponse({"error": "No file provided"}, status=400)

    # Get the uploaded file
    file = request.FILES['file']
    
    # Extract text based on file type (PDF or DOCX)
    file_extension = file.name.split('.')[-1].lower()
    
    try:
        # Extract text from PDF file
        if file_extension == 'pdf':
            pdf_reader = PyPDF2.PdfReader(file)
            extracted_text = ''
            for page in pdf_reader.pages:
                extracted_text += page.extract_text()

        # Extract text from DOCX file
        elif file_extension == 'docx':
            doc = docx.Document(file)
            extracted_text = ''
            for para in doc.paragraphs:
                extracted_text += para.text + '\n'

        else:
            return JsonResponse({"error": "Unsupported file format"}, status=400)

        # Generate prescription using Gemini
        model = genai.GenerativeModel("gemini-pro")

        # Send the extracted text to Gemini with the prompt
        prompt = f"Using the following prescription document, generate a prescription for the patient:\n{extracted_text}"

        response = model.generate_content(prompt)
        generated_text = response.text if response.text else "No response from Gemini."

        return JsonResponse({"prescription": generated_text}, json_dumps_params={'indent': 4})

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
@api_view(['POST'])
def generate_summary(request):
    """Generate a prescription from a document using Gemini."""
    
    # Check if the request contains a file
    if 'file' not in request.FILES:
        return JsonResponse({"error": "No file provided"}, status=400)

    # Get the uploaded file
    file = request.FILES['file']
    
    # Extract text based on file type (PDF or DOCX)
    file_extension = file.name.split('.')[-1].lower()
    
    try:
        # Extract text from PDF file
        if file_extension == 'pdf':
            pdf_reader = PyPDF2.PdfReader(file)
            extracted_text = ''
            for page in pdf_reader.pages:
                extracted_text += page.extract_text()

        # Extract text from DOCX file
        elif file_extension == 'docx':
            doc = docx.Document(file)
            extracted_text = ''
            for para in doc.paragraphs:
                extracted_text += para.text + '\n'

        else:
            return JsonResponse({"error": "Unsupported file format"}, status=400)

        # Generate prescription using Gemini
        model = genai.GenerativeModel("gemini-pro")

        # Send the extracted text to Gemini with the prompt
        prompt = f"Using the following document, generate a summary and overview of condition for the patient:\n{extracted_text}. do not include special symbols like * or nextline characters in the generated text, return a clean text."

        response = model.generate_content(prompt)
        generated_text = response.text if response.text else "No response from Gemini."

         # Apply regex cleaning
        cleaned_text = re.sub(r"\*\s*", "", generated_text)  # Remove '*' symbols
        # cleaned_text = re.sub(r"\n+", " ", cleaned_text).strip()  # Remove excessive newlines and trim spaces

        return JsonResponse({"prescription": cleaned_text}, json_dumps_params={'indent': 4})

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
@api_view(['POST'])
def generate_mom(request):
    """Generate a Minutes of Meeting (MoM) from a document using Gemini."""
    
    # Check if the request contains a file
    if 'file' not in request.FILES:
        return JsonResponse({"error": "No file provided"}, status=400)

    # Get the uploaded file
    file = request.FILES['file']
    
    # Extract text based on file type (PDF or DOCX)
    file_extension = file.name.split('.')[-1].lower()
    
    try:
        # Extract text from PDF file
        if file_extension == 'pdf':
            pdf_reader = PyPDF2.PdfReader(file)
            extracted_text = ''
            for page in pdf_reader.pages:
                extracted_text += page.extract_text()

        # Extract text from DOCX file
        elif file_extension == 'docx':
            doc = docx.Document(file)
            extracted_text = ''
            for para in doc.paragraphs:
                extracted_text += para.text + '\n'

        else:
            return JsonResponse({"error": "Unsupported file format"}, status=400)

        # Generate prescription using Gemini
        model = genai.GenerativeModel("gemini-pro")

        # Send the extracted text to Gemini with the prompt
        prompt = f"Using the following document, generate a Minutes of Meeting for the meeting between the patient and the doctor:\n{extracted_text} The format should include agenda of the meet, response of the meet, and ending statement. Do not include special symbols like * or newline characters in the generated text, return a clean text."

        response = model.generate_content(prompt)
        generated_text = response.text if response.text else "No response from Gemini."

        # Apply regex cleaning
        cleaned_text = re.sub(r"\*\s*", "", generated_text)  # Remove '*' symbols
        # cleaned_text = re.sub(r"\n+", " ", cleaned_text).strip()  # Remove excessive newlines and trim spaces

        return JsonResponse({"mom": cleaned_text}, json_dumps_params={'indent': 4})

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


# API to Get All Patients
@api_view(['POST'])
def get_all_patients(request):
    patients_ref = db.reference("Users/patients")
    patients = patients_ref.get()
    
    if not patients:
        return JsonResponse({'message': 'No patients found'}, status=status.HTTP_404_NOT_FOUND)
    
    return JsonResponse({'patients': patients}, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_patient_details(request):
    patient_id = request.GET.get('patient_id')  # Extract patient_id from query params
    
    if not patient_id:
        return JsonResponse({'error': 'Patient ID is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    patient_ref = db.reference(f"Users/patients/{patient_id}")
    patient = patient_ref.get()
    
    if not patient:
        return JsonResponse({'message': 'Patient not found'}, status=status.HTTP_404_NOT_FOUND)
    
    return JsonResponse({'patient': patient}, status=status.HTTP_200_OK)


# API to Add an Appointment for a Doctor
@api_view(['POST'])
def add_appointment(request):
    doctor_id = request.data.get('doctor_id')
    patient_name = request.data.get('patient_name')
    past_medical_record = request.data.get('past_medical_record', '')
    appointment_time = request.data.get('appointment_time')
    appointment_date = request.data.get('appointment_date')
    purpose = request.data.get('purpose')

    if not all([doctor_id, patient_name, appointment_time, appointment_date, purpose]):
        return Response({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

    # Generate a unique appointment ID
    appointment_id = str(uuid.uuid4())

    # Reference to the specific doctor's appointments in Firebase
    appointments_ref = db.reference(f"Users/doctors/{doctor_id}/appointments/{appointment_id}")

    # Store appointment details
    appointment_data = {
        "appointment_id": appointment_id,
        "patient_name": patient_name,
        "past_medical_record": past_medical_record,
        "appointment_time": appointment_time,
        "appointment_date": appointment_date,
        "purpose": purpose,
        "created_at": str(datetime.utcnow()),
    }

    appointments_ref.set(appointment_data)

    return Response({'message': 'Appointment added successfully', 'appointment_id': appointment_id}, status=status.HTTP_201_CREATED)


# API to Fetch Appointments for a Specific Doctor
@api_view(['GET'])
def get_appointments(request, doctor_id):
    # Reference to the specific doctor's appointments in Firebase
    appointments_ref = db.reference(f"Users/doctors/{doctor_id}/appointments")
    appointments = appointments_ref.get()

    if not appointments:
        return JsonResponse({'message': 'No appointments found'}, status=status.HTTP_404_NOT_FOUND)

    return JsonResponse({'appointments': appointments}, status=status.HTTP_200_OK)


def parse_medical_report(report_text):
    """Extract and structure the medical report text into a JSON format."""

    # Define the section headers pattern (Markdown-style bold)
    section_pattern = r"\*\*(.*?)\*\*"

    # Split the report into sections using the pattern
    parts = re.split(section_pattern, report_text)

    # Dictionary to store structured data
    structured_report = {"Medical Report": parts[0].strip()} if parts[0].strip() else {}

    # Stop processing if "Follow-Up" section is reached
    stop_section = "Follow-Up"

    for i in range(1, len(parts), 2):
        section_name = parts[i].strip()
        content = parts[i + 1].strip() if i + 1 < len(parts) else ""

        # Stop at "Follow-Up"
        if stop_section in section_name:
            structured_report[section_name] = content
            break

        # Convert bullet points into lists
        if "*" in content:
            content_lines = content.split("\n")
            formatted_content = []
            for line in content_lines:
                line = line.strip()
                if line.startswith("*"):
                    formatted_content.append(line.lstrip("* ").strip())
                elif formatted_content:
                    formatted_content[-1] += " " + line  # Merge multiline points
                else:
                    formatted_content.append(line)
            structured_report[section_name] = formatted_content
        else:
            structured_report[section_name] = content

    return structured_report


@api_view(['POST'])
def get_medical_report(request):
    """Fetch, clean, and return the structured medical report from Firebase."""

    global patient_report

    # Reference to the "Report" node in Firebase
    reports_ref = db.reference("Report")
    report_data = reports_ref.get()

    if not report_data:
        return JsonResponse({'error': 'Report not found'}, status=404)

    # Extract the first available report text
    medical_report = report_data

    if not medical_report:
        return JsonResponse({'error': 'No report text found'}, status=404)

    # Update the global variable
    patient_report = medical_report
    # Parse and structure the report
    structured_report = parse_medical_report(medical_report)

    return JsonResponse(structured_report, json_dumps_params={'indent': 4})


@api_view(['POST'])
def edit_medical_report(request):
    """Update the medical report in Firebase with the new text."""
    
    # Ensure that the new report text is provided in the request body
    new_report_text = request.data.get("report_text", None)
    
    if not new_report_text:
        return JsonResponse({"error": "No report text provided"}, status=400)
    
    try:
        # Reference to the "Report" node in Firebase
        reports_ref = db.reference("Report")

        # Update the report text in Firebase
        reports_ref.set(str(new_report_text))

        return JsonResponse({"message": "Report updated successfully"}, status=200)
    
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
 
# mistral-7b model
@api_view(['POST'])
def generate_medical_summary(request):
    """Generates a medical summary using the Mistral 7B model."""

    try:
        # Get input text from request
        patient_data = request.data.get("report")
        
        if not patient_data:
            return JsonResponse({"error": "Medical report is required"}, status=400)

        # Simulating Mistral 7B model processing
        model_id = "mistral-7b"
        hash_key = hashlib.sha256(patient_data.encode()).hexdigest()[:10]  # Shortened hash

        # Mock summary generation
        generated_summary = (
            f"[Model: {model_id}] Based on the provided medical report, the patient's condition "
            f"indicates signs of improvement with prescribed medications. Further monitoring "
            f"is recommended to assess recovery progress."
        )

        return JsonResponse({"summary": generated_summary, "id": hash_key}, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@api_view(['POST'])
def generate_medical_diagnosis(request):
    """Generates a medical diagnosis using the Mistral 7B model."""
    
    try:
        # Get patient symptoms from the request
        patient_symptoms = request.data.get("symptoms", None)
        
        if not patient_symptoms:
            return JsonResponse({"error": "Symptoms data is required"}, status=400)

        # Simulating Mistral 7B model processing
        model_id = "mistral-7b"
        diagnosis = (
            f"[Model: {model_id}] Based on the provided symptoms, the patient may have a viral "
            "infection causing the fever and rash. Further tests are recommended to confirm the diagnosis."
        )

        return JsonResponse({"diagnosis": diagnosis}, status=200)
    
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@api_view(['POST'])
def generate_medical_mom(request):
    """Generates Minutes of Meeting (MoM) using the Mistral 7B model."""
    
    try:
        # Get meeting notes from the request
        meeting_notes = request.data.get("notes", None)
        
        if not meeting_notes:
            return JsonResponse({"error": "Meeting notes are required"}, status=400)

        # Simulating Mistral 7B model processing
        model_id = "mistral-7b"
        mom = (
            f"[Model: {model_id}] The meeting discussed the patient's treatment plan, which includes "
            "prescription changes and further follow-up care. The doctor provided detailed explanations "
            "on the medication schedule."
        )

        return JsonResponse({"minutes_of_meeting": mom}, status=200)
    
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@api_view(['POST'])
def generate_medical_analysis(request):
    """Generates a medical analysis report using the Mistral 7B model."""
    
    try:
        # Get analysis input from the request
        analysis_input = request.data.get("input_data", None)
        
        if not analysis_input:
            return JsonResponse({"error": "Analysis input data is required"}, status=400)

        # Simulating Mistral 7B model processing
        model_id = "mistral-7b"
        analysis = (
            f"[Model: {model_id}] The provided data suggests that the patient is responding well to the "
            "prescribed treatment, showing improvement in all key health metrics. Continued monitoring "
            "is recommended."
        )

        return JsonResponse({"analysis_report": analysis}, status=200)
    
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


# mistral-7b model end


# Function to generate a random hash
def generate_random_hash(length=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

@api_view(['POST'])
def save_prescription(request):
    """Accepts prescription details and stores them under a random hash in the Firebase database."""

    # Validate the request body
    data = request.data
    required_fields = ['frequency', 'name', 'note', 'timeOfDay']

    # Ensure all required fields are present
    for field in required_fields:
        if field not in data:
            return JsonResponse({'error': f'Missing required field: {field}'}, status=400)

    frequency = data['frequency']
    name = data['name']
    note = data['note']
    time_of_day = data['timeOfDay']

    # Validate the values for 'frequency' and 'timeOfDay'
    valid_frequencies = ["Everyday", "3 times a week", "2 times a week", "Once a week"]
    valid_times_of_day = ["Morning", "Afternoon", "Evening", "Night"]

    if frequency not in valid_frequencies:
        return JsonResponse({'error': 'Invalid frequency value. Choose from: Everyday, 3 times a week, 2 times a week, Once a week.'}, status=400)
    if time_of_day not in valid_times_of_day:
        return JsonResponse({'error': 'Invalid timeOfDay value. Choose from: Morning, Afternoon, Evening, Night.'}, status=400)

    # Generate a random hash for the path
    random_hash = generate_random_hash()

    # Prepare the data to be stored
    prescription_data = {
        'frequency': frequency,
        'name': name,
        'note': note,
        'timeOfDay': time_of_day
    }

    # Store the prescription data under 'medicines/<random_hash>'
    medicines_ref = db.reference(f'medicines/{random_hash}')
    medicines_ref.set(prescription_data)

    return JsonResponse({'success': 'Prescription saved successfully', 'medicine_id': random_hash}, status=201)



@api_view(['POST'])
def save_mom(request):
    """Saves the Minutes of Meeting (MoM) in Firebase under 'MinutesOfMeet/<random_hash>'."""

    try:
        # Get MoM data from the request
        data = request.data.get("mom")
        
        if not data:
            return JsonResponse({"error": "MoM data is required"}, status=400)

        # Generate a unique hash for the entry
        hash_key = hashlib.sha256(data.encode()).hexdigest()[:10]  # Shortened hash

        # Firebase reference
        mom_ref = db.reference(f"MinutesOfMeet/{hash_key}")

        # Save data to Firebase
        mom_ref.set({"mom": data})

        return JsonResponse({"message": "MoM saved successfully", "id": hash_key}, status=201)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
    



@api_view(['POST'])
def save_analysis(request):
    """Saves the Minutes of Meeting (MoM) in Firebase under 'Analysis/<random_hash>'."""

    try:
        # Get MoM data from the request
        data = request.data.get("analysis")
        
        if not data:
            return JsonResponse({"error": "analysis data is required"}, status=400)

        # Generate a unique hash for the entry
        hash_key = hashlib.sha256(data.encode()).hexdigest()[:10]  # Shortened hash

        # Firebase reference
        analysis_ref = db.reference(f"Analysis/{hash_key}")

        # Save data to Firebase
        analysis_ref.set({"analysis": data})

        return JsonResponse({"message": "Analysis saved successfully", "id": hash_key}, status=201)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
    



