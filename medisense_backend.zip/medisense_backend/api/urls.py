from django.urls import path
from .views import *


urlpatterns = [
    path('register/', register_user, name='register_user'),
    path('login/', login_user, name='login_user'),
    path('get_all_doctors/', get_all_doctors, name='get_all_doctors'),
    path('all_patients/', get_all_patients, name='get_all_patients'),
    path('patient_detail/', get_patient_details, name='get_patient_details'),
    path('add_appointment/', add_appointment, name='add_appointment'),
    path('get_appointments/', get_appointments, name='get_appointments'),
    path('get_report/', get_medical_report, name='get_report'),
    path('edit_report/', edit_medical_report, name='edit_report'),
    path('generate_diagnosis/', generate_diagnosis, name='generate_diagnosis'),
    path('generate_prescription/', generate_prescription, name='generate_prescription'),
    path('generate_summary/', generate_summary, name='generate_summary'),
    path('generate_mom/', generate_mom, name='generate_mom'),
    path('save_prescription/', save_prescription, name='save_prescription'),
    path('save_mom/', save_mom, name='save_mom'),
    path('save_analysis/', save_analysis, name='save_analysis'),
]
