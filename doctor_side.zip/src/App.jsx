import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React from "react";
import Sidebar from "./components/Sidebar";
import HomePage from "./pages/HomePage";
import { LoginOrRegister } from "./pages/LoginorRegister";
import { Login } from "./components/LoginRegister/Login";
import { Register } from "./components/LoginRegister/Register";
import Appointments from "./pages/Appointments";
import PatientDetail from "./components/Appointments/PatientDetail";
import PatientsList from "./components/Appointments/PatientsList";
import Prescription from "./components/Appointments/Prescription";
import MinutesOfMeet from "./components/Appointments/MinutesOfMeet";
import Analysis from "./components/Appointments/Analysis";

// Doctor Layout Component (Includes Sidebar)
const DoctorLayout = () => {
  const [collapsed, setCollapsed] = React.useState(false);

  return (
    <div className="flex">
      {/* Sidebar for Doctor Routes */}
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Main Content */}
      <div className="flex-1 p-4">
        <Routes>
          <Route path="home" element={<HomePage />} />
          <Route path="appointments" element={<Appointments />} />
          <Route path="patients" element={<PatientsList />} />
          <Route path="patient/:id" element={<PatientDetail />} >
        
          </Route>
        </Routes>
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Authentication Routes */}
        <Route path="/" element={<LoginOrRegister />} >
        <Route path="" element={<Login />} />
        <Route path="register" element={<Register />} />
        
</Route>
          <Route path="/minutes" element={<MinutesOfMeet />} />
          <Route path="/prescription" element={<Prescription />} />
          <Route path="/analysis" element={<Analysis />} />
        {/* Doctor Routes (Includes Sidebar) */}
        <Route path="/doctor/*" element={<DoctorLayout />} />
      </Routes>
    </Router>
  );
}

export default App; 