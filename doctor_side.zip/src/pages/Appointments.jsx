import React from 'react'
import PatientsList from '../components/Appointments/PatientsList'

const Appointments = () => {
  return (
    <div>
      <PatientsList/>
    </div>
  )
}

export default Appointments
