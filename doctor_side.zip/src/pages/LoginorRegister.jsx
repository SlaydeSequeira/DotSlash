import React from 'react';
import { Outlet } from 'react-router-dom';

const LoginOrRegister = () => {
  return (
    <div className="flex h-screen">
      {/* Left Half - Welcome Section with Gradient Background */}
      <div className="w-1/2 bg-gradient-to-r from-indigo-600 via-blue-500 to-teal-400 flex items-center justify-center text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-black opacity-50 z-0"></div>
        <div className="z-10 text-center">
          <h1 className="text-5xl font-extrabold leading-tight mb-4 animate__animated animate__fadeInUp">
            Welcome to <span className="text-white-300">Medisense</span>
          </h1>
          <p className="text-lg max-w-xs mx-auto mb-6">
            A platform for managing your health in a smart, efficient way.
          </p>
          <p className="text-sm opacity-80">Login or Register to get started</p>
        </div>
      </div>

      {/* Right Half - Login/Register Form Section */}
      <div className="w-1/2 flex items-center justify-center bg-gradient-to-tl from-gray-200 to-gray-300">
        {/* <div className="w-full max-w-md p-10 bg-white rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-gray-700">Join Medisense</h2>
            <p className="text-gray-600 mt-2">Please sign in or create an account</p>
          </div> */}
          <Outlet />
        {/* </div> */}
      </div>
    </div>
  );
};

export { LoginOrRegister };
