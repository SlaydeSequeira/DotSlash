import React from 'react';
import TaskManager from '../components/HomePage/TaskManager';

const HomePage = () => {
  const doctorName = "Doctor!"; // Replace with dynamic data from backend later

  return (
    <div className="p-6">
      {/* Greeting Text */}
      <h1 className="text-2xl font-semibold mb-4">Hey, {doctorName}! 👋</h1>

      {/* Task Manager */}
      <TaskManager />

    

        <div className="bg-gray-100 p-4 rounded-md shadow-md min-h-[150px]">
          {/* Future Element 2 - Replace with actual component */}
          <p className="text-gray-600">[Placeholder for future feature]</p>
        </div>
      {/* </div> */} 
    </div>
  );
};

export default HomePage;
