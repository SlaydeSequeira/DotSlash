import { Home, Calendar, Settings, LogOut, ChevronLeft, ChevronRight, Bot } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

// Define the navItems array with icons, labels, and href links
const navItems = [
  { icon: Home, label: "Home", href: "/home" },
  { icon: Calendar, label: "Appointments", href: "/appointments" },
  // { icon: Bot, label: "AI", href: "/chat" },
  // { icon: Settings, label: "Settings", href: "/settings" },
];

const Sidebar = ({ className, collapsed, setCollapsed }) => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div
      className={`relative pb-12 min-h-screen transition-all duration-300 ${
        collapsed ? "w-16" : "w-64"
      } ${className}`}
    >
      <button
        className="absolute -right-3 top-6 z-10 rounded-full border shadow-md p-2"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
      </button>

      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <h2
            className={`mb-2 px-4 text-lg font-semibold transition-all duration-300 ${
              collapsed && "opacity-0"
            }`}
          >
            Doctor Dashboard
          </h2>
          <div className="space-y-1">
            {navItems.map((item) => {
              const fullPath = `/doctor${item.href}`; // Ensure correct absolute paths
              return (
                <div
                  key={item.href}
                  className={`w-full flex items-center p-2 rounded-md cursor-pointer transition-all duration-300 ${
                    location.pathname === fullPath
                      ? "bg-gray-200 text-gray-800"
                      : "hover:bg-gray-100 text-gray-600"
                  } ${collapsed && "px-2"}`}
                  onClick={() => navigate(fullPath)}
                >
                  <item.icon
                    className={`h-4 w-4 ${!collapsed && "mr-2"} ${
                      location.pathname === fullPath
                        ? "text-gray-800"
                        : "text-gray-600"
                    }`}
                  />
                  <span
                    className={`transition-all duration-300 ${
                      collapsed && "w-0 overflow-hidden opacity-0"
                    }`}
                  >
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 w-full px-3 transition-all duration-300">
        <div
          className="w-full flex items-center p-2 rounded-md cursor-pointer text-red-500 hover:text-red-600 hover:bg-red-100"
          onClick={() => {} /* Handle logout */}
        >
          <LogOut className={`h-4 w-4 ${!collapsed && "mr-2"}`} />
          <span
            className={`transition-all duration-300 ${
              collapsed && "w-0 overflow-hidden opacity-0"
            }`}
          >
            Logout
          </span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
