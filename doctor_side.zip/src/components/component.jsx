import React from 'react'

const component = () => {
  return (
    <div>
      hi
    </div>
  )
}

export default component
