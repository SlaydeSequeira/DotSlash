import React, { useState } from 'react';
import { Button } from '../ui/Button'; // You should create a button component with tailwind styles
import { Trash2 } from 'lucide-react'; // Optional icon for delete button

const TaskManager = () => {
  const [tasks, setTasks] = useState([
    { id: 1, title: 'Follow up with patient John', dueDate: '2025-02-05' },
    { id: 2, title: 'Review test results for Sarah', dueDate: '2025-02-10' },
  ]);
  const [newTask, setNewTask] = useState('');
  const [newTaskDate, setNewTaskDate] = useState('');

  const handleAddTask = (e) => {
    e.preventDefault(); // Prevent page reload on form submission
    if (newTask && newTaskDate) {
      setTasks([
        ...tasks,
        {
          id: tasks.length + 1,
          title: newTask,
          dueDate: newTaskDate,
        },
      ]);
      setNewTask('');
      setNewTaskDate('');
    }
  };

  const handleDeleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold">Task Manager</h2>
        <div className="mt-4 flex gap-4">
          <form onSubmit={handleAddTask} className="w-full flex gap-4">
            <input
              type="text"
              placeholder="Enter new task"
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              className="border border-gray-300 p-2 rounded-md w-full"
            />
            <input
              type="date"
              value={newTaskDate}
              onChange={(e) => setNewTaskDate(e.target.value)}
              className="border border-gray-300 p-2 rounded-md"
            />
            <Button
              type="submit" // Ensure button triggers form submission
              className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600"
            >
              Add Task
            </Button>
          </form>
        </div>
      </div>

      <div className="space-y-4">
        {tasks.map((task) => (
          <div key={task.id} className="flex items-center justify-between p-4 bg-white rounded-md shadow-md">
            <div>
              <h3 className="font-semibold">{task.title}</h3>
              <p className="text-sm text-gray-500">Due Date: {new Date(task.dueDate).toLocaleDateString()}</p>
            </div>
            <Button
              onClick={() => handleDeleteTask(task.id)}
              className="text-red-500 hover:text-red-600 bg-red-100 p-2 rounded-md"
            >
              <Trash2 className="h-5 w-5" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskManager;
