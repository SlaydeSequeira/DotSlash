export default function ActionPanel() {
    return (
      <div className="w-full p-6 bg-white rounded-2xl shadow-lg space-y-6">
      
        <Section title="Generate Minutes of the Meeting" buttonText="Generate" route="/minutes" />
        <Section title="Generate Analysis of the Patient" buttonText="Analysis" route="/analysis" />
        <Section title="Add Prescription" buttonText="Add" route="/prescription" />
      </div>
    );
  }
  
  function Section({ title, buttonText, route }) {
    return (
      <div className="flex justify-between items-center p-4 bg-gray-100 rounded-xl">
        <span className="text-lg font-semibold">{title}</span>
        <a
          href={route}
          className="px-4 py-2 bg-green-600 text-white rounded-lg shadow-md hover:bg-green-700 transition"
        >
          {buttonText}
        </a>
      </div>
    );
  }
  