import React from 'react';

const MomDiv = () => {
  return (
    <div className="p-6 text-center">
      <h2 className="text-2xl font-bold text-blue-600">Generate Minutes of the Meeting</h2>
      <p className="mt-2 text-gray-700">MOM content will be generated here.</p>
    </div>
  );
};

export default MomDiv;
