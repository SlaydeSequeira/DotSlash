import React, { useState, useEffect } from 'react';
import { Outlet, useParams } from 'react-router-dom';
import Summary from './Summary';
import ActionPanel from './ActionPanel';
import { Outdent } from 'lucide-react';

function Section({ title, buttonText, route }) {
  return (
    <div className="flex justify-between items-center p-4 bg-gray-100 rounded-xl">
      <span className="text-lg font-semibold">{title}</span>
      <a
        href={route}
        className="px-4 py-2 bg-green-600 text-white rounded-lg shadow-md hover:bg-green-700 transition"
      >
        {buttonText}
      </a>
    </div>
  );
}

const PatientDetail = () => {
  const { id } = useParams();
  const [patientData, setPatientData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`https://bfd9-14-139-121-51.ngrok-free.app/api/patient_detail/?patient_id=${id}/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
    })
      .then((response) => response.json()) // Parse response as JSON
      .then((data) => {
        console.log('Parsed Response:', data); // Log parsed response
        setPatientData(data.patient); // Set patient data to state
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-gray-500">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-red-500">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      {/* Left Side: Display Patient Data */}
      <div className="w-1/2 p-6 bg-gray-100 shadow-md overflow-auto">
        <h1 className="text-3xl font-bold mb-6 text-center text-green-700">Patient Details</h1>
        <div className="bg-white p-4 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold text-gray-700">Patient Information</h2>
          <div className="flex items-center space-x-4 mt-4">
            {/* Avatar Image */}
            
            <img
              src={`https://avatar.iran.liara.run/public/2`}
              alt="Patient Avatar"
              className="w-16 h-16 rounded-full border border-gray-300"
            />
            {/* Patient Info */}
            <div>
              <p><strong>Name:</strong> {patientData?.username}</p>
              <p><strong>Email:</strong> {patientData?.email}</p>
            </div>
          </div>

          {/* Meeting Section */}
          <div className="mt-6 bg-gray-50 p-4 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700">Get on a meet with {patientData?.username}</h3>
            <p className="mt-2 text-gray-600">Click below to attend a meeting with the patient.</p>
            <a
              href="https://aryan.digitalsamba.com/demo-room"
              className="mt-4 inline-block px-6 py-2 bg-green-600 text-white rounded-full text-center hover:bg-green-700 transition-colors"
            >
              Link 
            </a>
          </div>
          <div className="w-full p-6 bg-white rounded-2xl shadow-lg space-y-6">
      
        <Section title="Generate Minutes of the Meeting" buttonText="Generate" route="/minutes"/>
        <Section title="Generate Analysis of the Patient" buttonText="Analysis"route="/analysis"/>
        <Section title="Add Prescription" buttonText="Add" route="/prescription"/>
      </div>
        </div>
      </div>


      {/* Right Side: Placeholder for Another Component */}
      <div className="w-1/2 p-6 bg-white flex justify-center items-center">
        <Summary/>
      </div>
    </div>
  );
};

export default PatientDetail;
