import React, { useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

const Analysis = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [generatedText, setGeneratedText] = useState("");
  const [editedText, setEditedText] = useState("");

  const { id } = useParams();

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async (event) => {
    event.preventDefault();
    if (!file) {
      alert("Please select a PDF file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      setUploading(true);
      const response = await axios.post(
        `https://bfd9-14-139-121-51.ngrok-free.app/api/generate_summary/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      alert("File uploaded successfully!");
      setGeneratedText(response.data['prescription']);
      setEditedText(response.data['prescription']);
    } catch (error) {
      alert("File upload failed. Please try again.");
      console.error("Error during file upload:", error.response ? error.response.data : error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSaveChanges = async () => {
    if (!editedText) {
      alert("Please enter some text before saving.");
      return;
    }

    try {
      const response = await axios.post(
        `https://bfd9-14-139-121-51.ngrok-free.app/api/save_analysis/`,
        { "analysis": editedText },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      alert("Changes saved successfully!");
      console.log(response.data);
    } catch (error) {
      alert("Failed to save changes. Please try again.");
      console.error("Error during save:", error.response ? error.response.data : error.message);
    }
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50">
      <div className="flex flex-col md:flex-row p-6 max-w-5xl w-full bg-white shadow-lg rounded-2xl">
        {/* Left Section */}
        <div className="w-full md:w-1/3 p-6 bg-white shadow-md rounded-2xl border border-gray-200">
          <h2 className="text-lg font-bold mb-4 text-green-600">Upload PDF to Analyze</h2>
          <p className="text-sm mb-4 text-gray-700">
            Upload a readable PDF to generate an editable analysis.
          </p>
          <form onSubmit={handleUpload} className="space-y-4">
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              className="border border-gray-300 p-2 w-full rounded-lg text-gray-700"
            />
            <button
              type="submit"
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg w-full"
              disabled={uploading}
            >
              {uploading ? "Uploading..." : "Upload PDF"}
            </button>
          </form>
        </div>

        {/* Right Section */}
        <div className="w-full md:w-2/3 p-6 mt-6 md:mt-0 md:ml-6 bg-white shadow-md rounded-2xl border border-gray-200">
          {generatedText && (
            <div>
              <h3 className="font-bold text-xl mb-2 text-green-600">Generated Analysis</h3>
              <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg text-gray-700"
                rows="12"
              ></textarea>
              <button
                onClick={handleSaveChanges}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 mt-3 rounded-lg w-full"
              >
                Save Changes
              </button>
            </div>
          )}
        </div>
      </div>
      {generatedText && (
        <div className="mt-6">
          <button
            onClick={() => window.location.href = "/doctor/patient/42"}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
          >
            Back
          </button>
        </div>
      )}
    </div>
  );
};

export default Analysis;
