import axios from 'axios';
import { useEffect, useState } from 'react';

const Summary = () => {
  const [reportText, setReportText] = useState(''); // Store report as a single text field
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReport = async () => {
      try {
        const response = await axios.post('https://bfd9-14-139-121-51.ngrok-free.app/api/get_report/');
        console.log(response.data);
        setReportText(JSON.stringify(response.data, null, 2)); // Convert object to formatted string
        setLoading(false);
      } catch (error) {
        console.error('Error fetching report:', error);
        setLoading(false);
      }
    };

    fetchReport();
  }, []);

  const handleSave = async () => {
    try {
      const updatedReport = JSON.parse(reportText); // Convert text back to JSON
      const response = await axios.post('https://bfd9-14-139-121-51.ngrok-free.app/api/edit_report/', JSON.stringify({"report_text":updatedReport}), {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      console.log('Report updated:', response.data);
      alert('Report saved successfully!');
    } catch (error) {
      console.error('Error saving the report:', error);
      alert('There was an error saving the report. Make sure the JSON format is correct.');
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto bg-white rounded-lg shadow-md" style={{width:"500px"}}>
      <h1 className="text-2xl font-bold mb-6">AI Generated Report</h1>

      {/* Editable Text Area for Full Report */}
      <textarea
        className="w-full p-4 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
        rows={20}
        value={reportText}
        onChange={(e) => setReportText(e.target.value)}
      />

      {/* Save Button */}
      <div className="mt-4 flex justify-end">
        <button
          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          onClick={handleSave}
        >
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default Summary;
