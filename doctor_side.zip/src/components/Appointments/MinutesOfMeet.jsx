import React, { useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const MinutesOfMeet = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [generatedText, setGeneratedText] = useState(""); // Store the response text
  const [editedText, setEditedText] = useState(""); // Store the edited text
  
  const { id } = useParams();
  const navigate = useNavigate();

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async (event) => {
    event.preventDefault();
    if (!file) {
      alert("Please select a PDF file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      setUploading(true);
      const response = await axios.post(
        `https://bfd9-14-139-121-51.ngrok-free.app/api/generate_mom/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      alert("File uploaded successfully!");
      setGeneratedText(response.data['mom']);
      setEditedText(response.data['mom']);
    } catch (error) {
      alert("File upload failed. Please try again.");
      console.error("Error during file upload:", error.response ? error.response.data : error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSaveChanges = async () => {
    if (!editedText) {
      alert("Please enter some text before saving.");
      return;
    }

    try {
      const response = await axios.post(
        `https://bfd9-14-139-121-51.ngrok-free.app/api/save_mom/`,
        { "mom": editedText },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      alert("Changes saved successfully!");
      console.log(response.data);
    } catch (error) {
      alert("Failed to save changes. Please try again.");
      console.error("Error during save:", error.response ? error.response.data : error.message);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <div className="flex w-full max-w-4xl bg-white shadow-lg rounded-lg p-6">
        <div className="flex-1 p-4">
          <h2 className="text-xl font-bold mb-4 text-green-600">Upload Meeting Content</h2>
          <p className="text-green-600 mb-4">Upload meeting whiteboard screenshots or any meeting-related content.</p>
          <form onSubmit={handleUpload}>
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              className="border p-2 w-full mb-4 rounded-md"
            />
            <button
              type="submit"
              className="bg-green-600 text-white px-4 py-2 rounded-lg w-full"
              disabled={uploading}
            >
              {uploading ? "Uploading..." : "Upload PDF"}
            </button>
          </form>
        </div>

        <div className="flex-1 p-4 border-l border-green-600">
          {generatedText && (
            <div>
              <h3 className="font-bold mb-2 text-green-600">Generated Minutes of Meeting</h3>
              <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="w-full p-2 border rounded-md mb-4"
                rows="15"
              ></textarea>
              <button
                onClick={handleSaveChanges}
                className="bg-green-600 text-white px-4 py-2 rounded-lg w-full"
              >
                Save Changes
              </button>
            </div>
          )}
        </div>
      </div>
      
      {generatedText && (
        <button
          onClick={() => navigate("/doctor/patient/42")}
          className="mt-6 bg-green-600 text-white px-6 py-2 rounded-lg"
        >
          Back
        </button>
      )}
    </div>
  );
};

export default MinutesOfMeet;
