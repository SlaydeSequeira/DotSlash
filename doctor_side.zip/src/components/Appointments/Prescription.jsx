import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import ActionPanel from './ActionPanel';
import axios from 'axios';

const Prescription = () => {
  const { id } = useParams();
  const [patientData, setPatientData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [prescription, setPrescription] = useState({
    name: '',
    frequency: 'Everyday', // Default frequency
    note: '',
    timeOfDay: 'Morning', // Default time of day
  });

  useEffect(() => {
    fetch(`https://bfd9-14-139-121-51.ngrok-free.app/api/patient_detail/?patient_id=${id}/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Parsed Response:', data);
        setPatientData(data.patient);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPrescription({ ...prescription, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        'https://bfd9-14-139-121-51.ngrok-free.app/api/save_prescription/', 
        {
          frequency: prescription.frequency,
          name: prescription.name,
          note: prescription.note,
          timeOfDay: prescription.timeOfDay,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      if (response.status === 201) {
        alert('Prescription saved successfully!');
        console.log('Prescription ID:', response.data.medicine_id);
      } else {
        alert('Error saving prescription');
      }
    } catch (error) {
      console.error('Error submitting prescription:', error);
      alert('Failed to submit prescription');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-gray-500">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-red-500">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      <div className="w-1/2 p-6 bg-gray-100 shadow-md overflow-auto">
        {/* <h1 className="text-3xl font-bold mb-6 text-center text-green-700">Patient Details</h1> */}
        <div className="bg-white p-4 rounded-lg shadow-lg mt-25">
          {/* <h2 className="text-xl font-semibold text-gray-700">Patient Information</h2>
          <div className="flex items-center space-x-4 mt-4">
            <img
              src={`https://avatar.iran.liara.run/public/2`}
              alt="Patient Avatar"
              className="w-16 h-16 rounded-full border border-gray-300"
            />
            <div>
              <p><strong>Name:</strong> {patientData?.username}</p>
              <p><strong>Email:</strong> {patientData?.email}</p>
            </div>
          </div> */}
          {/* <div className="mt-6 bg-gray-50 p-4 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700">Get on a meet with patient?</h3>
            <p className="mt-2 text-gray-600">Click below to attend a meeting with the patient.</p>
            <a
              href="https://aryan.digitalsamba.com/demo-room"
              className="mt-4 inline-block px-6 py-2 bg-green-600 text-white rounded-full text-center hover:bg-green-700 transition-colors"
            >
              Link 
            </a>
          </div> */}
          <ActionPanel/>
          <div className="mt-6 self-center">
          <button
            onClick={() => window.location.href = "/doctor/patient/42"}
            className="bg-green-600 hover:bg-gfreen-700 text-white px-4 py-2 rounded-lg"
          >
            Back
          </button>
        </div>
        </div>
      </div>
      
      <div className="w-1/2 p-6 bg-white flex justify-center items-center">
        <form onSubmit={handleSubmit} className="bg-gray-100 p-6 rounded-lg shadow-lg w-full max-w-md">
          <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Prescribe Medication</h2>
          <div className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">Medication Name</label>
            <input
              type="text"
              name="name"
              value={prescription.name}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">Frequency</label>
            <select
              name="frequency"
              value={prescription.frequency}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            >
              <option value="Everyday">Everyday</option>
              <option value="3 times a week">3 times a week</option>
              <option value="2 times a week">2 times a week</option>
              <option value="Once a week">Once a week</option>
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">Notes</label>
            <textarea
              name="note"
              value={prescription.note}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">Time of Day</label>
            <select
              name="timeOfDay"
              value={prescription.timeOfDay}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400"
              required
            >
              <option value="Morning">Morning</option>
              <option value="Afternoon">Afternoon</option>
              <option value="Evening">Evening</option>
              <option value="Night">Night</option>
            </select>
          </div>
          <button
            type="submit"
            className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            Submit Prescription
          </button>
        </form>
      </div>
    </div>
  );
};

export default Prescription;
