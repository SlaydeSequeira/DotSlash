import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const PatientsList = () => {
  const [patients, setPatients] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('https://bfd9-14-139-121-51.ngrok-free.app/api/all_patients/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .then((data) => {
        setPatients(data.patients);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-gray-500">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-xl text-red-500">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Patients List</h1>
      <div className="space-y-6">
        {Object.entries(patients).map(([id, patient]) => (
          <div
            key={id}
            className="bg-white shadow-md rounded-lg p-6 flex flex-col items-start space-y-4 hover:shadow-xl transition-shadow duration-300"
          >
            <h2 className="text-2xl font-semibold text-green-700">{patient.username}</h2>
            <p className="text-lg text-gray-700">Email: {patient.email}</p>
            <p className="text-sm text-gray-500">
              Meeting scheduled at: {new Date(patient.joined_at).toLocaleString()}
            </p>
            <Link
              to={{
                pathname: `/doctor/patient/${id}`,
                state: { patient }, // Pass patient details
              }}
              className="mt-4 px-4 py-2 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors"
            >
              View Patient
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PatientsList;
