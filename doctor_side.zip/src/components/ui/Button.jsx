// ui/button.jsx
const Button = ({ onClick, children, className }) => (
    <button
      onClick={onClick}
      className={`px-4 py-2 font-semibold text-white rounded-md transition-all bg-green-300  ${className}`}
    >
      {children}
    </button>
  );
  
  export { Button };
  